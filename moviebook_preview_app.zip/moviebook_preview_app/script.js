const movies = [
  {name:"Avengers Endgame",rating:"8.4"},
  {name:"Pushpa 2",rating:"8.2"},
  {name:"Jawan",rating:"7.1"},
  {name:"Leo",rating:"7.8"}
];

const movieBox=document.getElementById("movies");
const booking=document.getElementById("booking");
let selectedMovie=null, selectedSeats=[];

function renderMovies(list=movies){
  movieBox.innerHTML="";
  list.forEach((m,i)=>{
    const card=document.createElement("div");
    card.className="card";
    card.innerHTML=`<div class="poster">${m.name}</div>
      <h3>${m.name}</h3><p>⭐ ${m.rating} | Action | Thriller</p>
      <button class="book">Book Now</button>`;
    card.querySelector("button").addEventListener("click",()=>openBooking(m));
    movieBox.appendChild(card);
  });
}

function openBooking(movie){
  selectedMovie=movie; selectedSeats=[];
  document.getElementById("selectedMovie").textContent=movie.name;
  document.getElementById("rating").textContent=movie.rating;
  renderSeats();
  booking.classList.remove("hidden");
  window.scrollTo({top:booking.offsetTop,behavior:"smooth"});
}

function renderSeats(){
  const box=document.getElementById("seats");
  box.innerHTML="";
  for(let i=1;i<=40;i++){
    const s=document.createElement("div");
    s.className="seat";
    s.textContent=i;
    s.addEventListener("click",()=>{
      s.classList.toggle("selected");
      if(s.classList.contains("selected")) selectedSeats.push(i);
      else selectedSeats=selectedSeats.filter(x=>x!==i);
    });
    box.appendChild(s);
  }
}

document.getElementById("backBtn").addEventListener("click",()=>{
  booking.classList.add("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
});

document.getElementById("search").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  renderMovies(movies.filter(m=>m.name.toLowerCase().includes(q)));
});

document.getElementById("confirm").addEventListener("click",()=>{
  const name=document.getElementById("name").value.trim();
  const mobile=document.getElementById("mobile").value.trim();
  const payment=document.querySelector('input[name="pay"]:checked');

  if(!name || !mobile || selectedSeats.length===0 || !payment){
    alert("Please enter your details, select seats and payment method.");
    return;
  }

  document.getElementById("successText").textContent =
    `Your ${selectedSeats.length} ticket(s) for ${selectedMovie.name} have been booked. Seats: ${selectedSeats.join(", ")}.`;
  document.getElementById("success").classList.remove("hidden");

  setTimeout(()=>{ try{ window.close(); }catch(e){} },3000);
});

document.getElementById("closeWindow").addEventListener("click",()=>{
  try{window.close();}catch(e){}
  document.getElementById("success").classList.add("hidden");
  alert("Booking completed. Your browser may block closing a normal tab.");
});

renderMovies();
